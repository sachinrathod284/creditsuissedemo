package com.logprocess.demo.controller;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.logprocess.demo.pojo.LogRequestProcess;
import com.logprocess.demo.pojo.LogService;

@RestController
public class DemoController {
	@Autowired
	private LogService aservice;

	private static final Logger LOGGER = LoggerFactory.getLogger(DemoController.class);

	@PostMapping("/testFileProcess")
	public ResponseEntity<Object> testFileProcess(@RequestBody LogRequestProcess logRequestProcess)
			throws NumberFormatException, IOException {
		LOGGER.info("Starting...file process this list of files {}", logRequestProcess.getFilePath());
		aservice.processFiles(logRequestProcess.getFilePath());
		return ResponseEntity.ok("file processed");
	}

	@RequestMapping("/getData")
	@ResponseBody
	public ResponseEntity<Object> getData() throws NumberFormatException, IOException {
		LOGGER.info("Starting...getData which is processed and saved in DB");
		aservice.getData();
		return ResponseEntity.ok("got all file data");
	}
}