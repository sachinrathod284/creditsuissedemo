package com.logprocess.demo.fileprocess;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.logprocess.demo.pojo.LogFileData;


public class FileReaderTester {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	public static void main1(String[] args) throws ExecutionException, InterruptedException {

		ExecutorService executorService = Executors.newFixedThreadPool(10);
		List<FileReader> list = new ArrayList<>();
		List<Future<Map<String, List<LogFileData>>>> result = new ArrayList<>();
		List<Map<String, List<LogFileData>>> finalResult = new ArrayList<>();

		// adding files to list
		String folderPath = "C:\\install\\DBTestALLWorked\\log";
		File file = new File(folderPath);
		File[] listOfFiles = {};
		if (!file.isFile()) {
			listOfFiles = file.listFiles();
		}

		for (int i = 0; i < listOfFiles.length; i++) {
			list.add(new FileReader(listOfFiles[i].getAbsolutePath()));
		}

		// submitting task with callable
		for (int i = 0; i < list.size(); i++) {
			result.add(executorService.submit(list.get(i)));
			Future<Map<String, List<LogFileData>>> submit = executorService.submit(list.get(i));

		}

		// calculating result
		for (int i = 0; i < result.size(); i++) {
			System.out.println(result.get(i));
		}

		System.out.println(finalResult);
		executorService.shutdown();
	}
}