package com.logprocess.demo.fileprocess;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.logprocess.demo.pojo.LogFileData;
import com.logprocess.demo.pojo.LogFileDataDao;

@Component
@Lazy
public class FileReader implements Callable<Map<String, List<LogFileData>>> {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	LogFileDataDao logFileDataDao;

	String fileName;

	@Autowired
	public FileReader(String fileName) {
		this.fileName = fileName;
	}

	@Override
	public Map<String, List<LogFileData>> call() throws Exception {
		Gson gson = new Gson();
		Stream<String> stream = Files.lines(Paths.get(this.fileName));
		List<LogFileData> list = new ArrayList<>();
		stream.forEach(line -> {
			LogFileData logfile = gson.fromJson(line, LogFileData.class);
			list.add(logfile);
		});

		Map<String, List<LogFileData>> collectTmp = list.stream().collect(Collectors.groupingBy(LogFileData::getId));
		collectTmp.entrySet().forEach(item -> {
			calculateDiff(item.getValue());
		});

		return collectTmp;
	}

	private void calculateDiff(List<LogFileData> datatmp) {

		long diff = Math
				.abs(Long.parseLong(datatmp.get(0).getTimestamp()) - Long.parseLong(datatmp.get(1).getTimestamp()));
		if (diff >= 4) {

			datatmp.stream().forEach(item -> {
				item.setAlert("true");
			});
			logger.info("ALERT 4ms greater" + datatmp);
		} else {
			datatmp.stream().forEach(item -> {
				item.setAlert("false");
			});
			logger.info("ALERT 3ms greater" + datatmp);
		}

	}
}