package com.logprocess.demo.pojo;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class LogFileDataDao {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String SQL_NEW_LogFileData = "INSERT INTO LOGFILEDATA( ID, STATE , TYPE , HOST , TIMESTAMP , ALERT) VALUES(?,?,?,?,?,?)";
	private static final String SQL_FIND_ALL_CUSTOMERS = "SELECT * FROM LOGFILEDATA";

	public List<LogFileData> findAllLogFileDatas() {
		List<LogFileData> logfiles = jdbcTemplate.query(SQL_FIND_ALL_CUSTOMERS, new LogFileDataRowMapper());
		logger.info("data fetched using function findAllLogFileDatas" + logfiles);
		return logfiles;
	}

	public void saveLogFileData(LogFileData logfile) {
		jdbcTemplate.update(SQL_NEW_LogFileData, new Object[] { logfile.getId(), logfile.getState(), logfile.getType(),
				logfile.getHost(), logfile.getTimestamp(), logfile.getAlert() });
		logger.info("data saved using function saveLogFileData {} ", logfile);
	}

}