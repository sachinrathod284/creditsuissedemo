package com.logprocess.demo.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import javax.persistence.Id;

@Entity
@Table(name = "logfileEntity")
public class LogFileData {

	@Id
	@Column(name = "genkey")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int genkey;
	
	@Column(name = "id")
	private String id;
	@Column(name = "state")
	private String state;
	@Column(name = "type")
	private String type;
	@Column(name = "host")
	private String host;
	@Column(name = "timestamp")
	private String timestamp;
	@Column(name = "alert")
	private String alert;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getAlert() {
		return alert;
	}

	public void setAlert(String alert) {
		this.alert = alert;
	}

	@Override
	public String toString() {
		return "LogFileData [id=" + id + ", state=" + state + ", type=" + type + ", host=" + host + ", timestamp="
				+ timestamp + ", alert=" + alert + "]";
	}

}