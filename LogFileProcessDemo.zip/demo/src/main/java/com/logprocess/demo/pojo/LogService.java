package com.logprocess.demo.pojo;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.logprocess.demo.fileprocess.FileReader;

@Service
public class LogService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	LogFileDataDao logFileDataDao;

	public String  processFiles(String pathFileList) {

		ExecutorService executorService = Executors.newFixedThreadPool(10);
		List<FileReader> list = new ArrayList<>();
		List<Future<Map<String, List<LogFileData>>>> result = new ArrayList<>();

		// Getting the list of file and storing for thread processing
		// String folderPath = "C:\\install\\DBTestALLWorked\\log";
		File file = new File(pathFileList);
		File[] listOfFiles = {};
		if (!file.isFile()) {
			listOfFiles = file.listFiles();
		}

		// this will be maintained per filepath parallel processing should happen
		for (int i = 0; i < listOfFiles.length; i++) {
			FileReader fileReaderTmp = new FileReader(listOfFiles[i].getAbsolutePath());
			list.add(fileReaderTmp);
		}

		// this will be used per filepath one task submit
		for (int i = 0; i < list.size(); i++) {
			result.add(executorService.submit(list.get(i)));
		}

		// calculating result
		result.stream().forEach(res -> {
			try {
				Map<String, List<LogFileData>> map = res.get();
				map.entrySet().forEach(item -> {
					List<LogFileData> itemValue = item.getValue();
					logger.info("List values: {}", itemValue);
					saveToHSQLDB(itemValue);
				});
			} catch (InterruptedException | ExecutionException e) {
				logger.error(e.getMessage(), e);
				throw new RuntimeException(e.getMessage(), e);
			}
		});

		executorService.shutdown();
		return null;
	}

	private void saveToHSQLDB(List<LogFileData> datatmp) {
		datatmp.stream().forEach(logfile -> {
			logFileDataDao.saveLogFileData(logfile);
		});
		logger.info("Data is saved");
	}

	public String getData() {
		List<LogFileData> findAllCustomers = logFileDataDao.findAllLogFileDatas();
		findAllCustomers.stream().forEach(item -> {
			logger.info("data is: {}", item);
		});
		return "";
	}

}
