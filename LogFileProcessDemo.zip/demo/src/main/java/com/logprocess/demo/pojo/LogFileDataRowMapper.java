package com.logprocess.demo.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class LogFileDataRowMapper implements RowMapper<LogFileData> {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public LogFileData mapRow(ResultSet rs, int rowNum) throws SQLException {
		LogFileData logFileData = new LogFileData();

		logFileData.setId(rs.getString("ID"));
		logFileData.setState(rs.getString("STATE"));
		logFileData.setType(rs.getString("TYPE"));
		logFileData.setHost(rs.getString("HOST"));
		logFileData.setTimestamp(rs.getString("TIMESTAMP"));
		logFileData.setAlert(rs.getString("ALERT"));
		logger.info("Mapper data:" + logFileData.toString());
		return logFileData;
	}

}