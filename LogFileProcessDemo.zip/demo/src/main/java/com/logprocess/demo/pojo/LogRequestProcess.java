package com.logprocess.demo.pojo;

public class LogRequestProcess {

	String filePath;

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

}
