package com.logprocess.demo.controller;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.logprocess.demo.pojo.LogService;

@SpringBootTest
@AutoConfigureMockMvc
public class DemoControllertest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private LogService service;

	@Test
	public void getDataTest() throws Exception {
		this.mockMvc.perform(get("/getData")).andDo(print()).andExpect(status().isOk())
				.andExpect(content().string(containsString("got all file data")));
	}

	@Test
	public void logServiceShouldReturnMessageFromService() throws Exception {
		when(service.getData()).thenReturn("got all file data");
		this.mockMvc.perform(get("/getData")).andDo(print()).andExpect(status().isOk())
				.andExpect(content().string(containsString("got all file data")));
	}

	@Test
	public void logServiceShouldReturnMessageFromService1() throws Exception {
		when(service.processFiles(Mockito.anyString())).thenReturn("C:\\install\\DBTestALLWorked\\log\\logfile.txt");
		this.mockMvc.perform(get("/testFileProcess")).andDo(print()).andExpect(status().isOk())
				.andExpect(content().string(containsString("file processed")));
	}

}
